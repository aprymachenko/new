#!/bin/bash

/usr/local/apache-tomcat-8.5.35/bin/startup.sh

#while true 
#do
#	sleep 10
#	echo "I'm still here"	
#done
