#!/bin/bash

docker pull aprymachenko/locappmod:jenkinspipeline
docker run --name jenkinspipeline -p 8090:8080 -v appimage:/usr/local/AppImg -v appartifactrepo:/usr/local/ArtifactRepo -v devopsfiles:/usr/local/DevOpsImg -v jenkinspipeline:/var/jenkins_home -v /var/run/docker.sock:/var/run/docker.sock aprymachenko/locappmod:jenkinspipeline
docker rmi aprymachenko/locappmod:jenkinspipeline
docker rm jenkinspipeline

  

